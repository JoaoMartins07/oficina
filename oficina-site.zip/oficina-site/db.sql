CREATE DATABASE IF NOT EXISTS oficina;
USE oficina;

CREATE TABLE agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  email VARCHAR(100),
  telefone VARCHAR(20),
  servico VARCHAR(100),
  data DATE,
  status ENUM('espera', 'confirmado', 'cancelado') DEFAULT 'espera'
);

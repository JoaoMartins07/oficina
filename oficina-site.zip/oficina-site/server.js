// Configurações básicas permanecem as mesmas
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql2');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(session({
  secret: 'segredo_super_secreto',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // true se estiver usando HTTPS
}));

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) throw err;
  console.log('Ligado à base de dados MySQL');
});

// Páginas públicas
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/agendar', (req, res) => {
  res.sendFile(path.join(__dirname, 'agendar.html'));
});

// Rotas de administração
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  
  // Verifique se é o admin (substitua por sua lógica de banco de dados)
  if (email === 'admin@oficina.com' && password === 'senha_secreta') {
    req.session.loggedin = true;
    req.session.email = email;
    res.redirect('/painel');
  } else {
    res.send('Credenciais inválidas. <a href="/admin">Tentar novamente</a>');
  }
});

// Painel de admin (protegido)
app.get('/painel', (req, res) => {
  if (req.session.loggedin) {
    // Consulta ao banco de dados para obter agendamentos
    db.query('SELECT * FROM agendamentos', (err, results) => {
      if (err) throw err;
      
      // Renderiza uma página simples com os agendamentos
      let html = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Painel Admin</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
          <div class="container mt-4">
            <h2>Painel Administrativo</h2>
            <p>Bem-vindo, ${req.session.email}</p>
            <a href="/logout" class="btn btn-danger mb-3">Sair</a>
            
            <h3>Agendamentos</h3>
            <table class="table">
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>Email</th>
                  <th>Telefone</th>
                  <th>Serviço</th>
                  <th>Data</th>
                </tr>
              </thead>
              <tbody>
      `;
      
      results.forEach(agendamento => {
        html += `
          <tr>
            <td>${agendamento.nome}</td>
            <td>${agendamento.email}</td>
            <td>${agendamento.telefone}</td>
            <td>${agendamento.servico}</td>
            <td>${new Date(agendamento.data).toLocaleDateString()}</td>
          </tr>
        `;
      });
      
      html += `
              </tbody>
            </table>
          </div>
        </body>
        </html>
      `;
      
      res.send(html);
    });
  } else {
    res.redirect('/admin');
  }
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin');
  });
});

// Rota para processar agendamentos
app.post('/agendar', (req, res) => {
  const { nome, email, telefone, servico, data } = req.body;
  
  db.query(
    'INSERT INTO agendamentos (nome, email, telefone, servico, data) VALUES (?, ?, ?, ?, ?)',
    [nome, email, telefone, servico, data],
    (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Erro ao agendar');
      }
      res.send('Agendamento realizado com sucesso!');
    }
  );
});

app.listen(port, () => {
  console.log(`Servidor a correr em http://localhost:${port}`);
});
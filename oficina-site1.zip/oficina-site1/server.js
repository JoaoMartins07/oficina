require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Configura views com EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Sessão para login admin
app.use(session({
  secret: 'segredo_da_oficina',
  resave: false,
  saveUninitialized: false
}));

// Conexão MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',    // coloca a tua password MySQL
  database: 'oficina'
});

db.connect(err => {
  if (err) throw err;
  console.log('Ligado ao MySQL');
});

// Configura nodemailer
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL,
    pass: process.env.EMAIL_PASS
  }
});

// Middleware para proteger rotas admin
function autenticar(req, res, next) {
  if (req.session && req.session.admin) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Página inicial (exemplo simples, substitui pelo que quiseres)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Receber agendamento
app.post('/agendar', (req, res) => {
  const { nome, email, telefone, servico, data } = req.body;
  const sql = 'INSERT INTO agendamentos (nome, email, telefone, servico, data, status) VALUES (?, ?, ?, ?, ?, "em espera")';
  db.query(sql, [nome, email, telefone, servico, data], (err) => {
    if (err) throw err;

    // Envia email de confirmação "em espera"
    transporter.sendMail({
      from: process.env.EMAIL,
      to: email,
      subject: 'Confirmação de Agendamento',
      text: `Olá ${nome}, o seu serviço está em espera. Entraremos em contacto em breve.`
    });

    res.redirect('/agendar.html');  // página do formulário ou confirmação
  });
});

// Login admin - GET e POST
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/login.html'));
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (email === process.env.ADMIN_EMAIL && await bcrypt.compare(password, process.env.ADMIN_PASS_HASH)) {
    req.session.admin = true;
    res.redirect('/admin');
  } else {
    res.send('Login inválido. <a href="/login">Tentar de novo</a>');
  }
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Página admin protegida
app.get('/admin', autenticar, (req, res) => {
  db.query('SELECT * FROM agendamentos', (err, results) => {
    if (err) throw err;
    res.render('admin', { agendamentos: results });
  });
});

// Atualizar status do agendamento
app.post('/atualizar-status', autenticar, (req, res) => {
  const { id, status } = req.body;
  const sql = 'UPDATE agendamentos SET status = ? WHERE id = ?';
  db.query(sql, [status, id], (err) => {
    if (err) throw err;

    // Buscar dados para email
    db.query('SELECT email, nome FROM agendamentos WHERE id = ?', [id], (err, results) => {
      if (err) throw err;

      const { email, nome } = results[0];
      let mensagem = `Olá ${nome}, o status do seu serviço foi atualizado para: ${status}.`;
      if (status === 'confirmado') mensagem += ' Compareça na data agendada!';
      else if (status === 'cancelado') mensagem += ' Lamentamos, o seu pedido foi cancelado.';

      transporter.sendMail({
        from: process.env.EMAIL,
        to: email,
        subject: 'Atualização do seu agendamento',
        text: mensagem
      });

      res.redirect('/admin');
    });
  });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor a correr em http://localhost:${PORT}`));
